<?php 
$hostname = "localhost";
$username = "root";
$password = "";
$dbname = "rental_mobil";
    $conn = mysqli_connect($hostname, $username, $password, $dbname) or die (mysqli_error());
?> 